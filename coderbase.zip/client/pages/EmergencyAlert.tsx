import { useEffect, useState } from "react";
import { AlertTriangle, MapPin, Phone, X } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function EmergencyAlert() {
  const navigate = useNavigate();
  const [countdown, setCountdown] = useState(5);
  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [isSending, setIsSending] = useState(false);

  useEffect(() => {
    // Get current location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
        },
        (error) => {
          console.error("Error getting location:", error);
        }
      );
    }

    // Start countdown
    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          sendEmergencyAlert();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const sendEmergencyAlert = async () => {
    if (!location || isSending) return;

    setIsSending(true);
    try {
      // Send to emergency contacts and police dashboard
      const alertData = {
        timestamp: new Date().toISOString(),
        location: location,
        type: "PANIC_SCREAM_DETECTED",
        status: "ACTIVE",
      };

      // Mock API call to police dashboard
      console.log("Sending emergency alert:", alertData);

      // In production, this would be a real API call
      // await fetch("/api/emergency-alert", {
      //   method: "POST",
      //   headers: { "Content-Type": "application/json" },
      //   body: JSON.stringify(alertData),
      // });

      // Show confirmation
      setIsSending(true);
    } catch (error) {
      console.error("Error sending emergency alert:", error);
    }
  };

  const handleCancel = () => {
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-destructive/10 via-destructive/5 to-background flex items-center justify-center overflow-hidden relative">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 right-20 w-72 h-72 bg-destructive/20 rounded-full mix-blend-multiply filter blur-3xl animate-blob"></div>
        <div className="absolute -bottom-8 left-20 w-72 h-72 bg-secondary/20 rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-2000"></div>
      </div>

      <div className="relative z-10 max-w-2xl mx-auto px-4 text-center">
        {/* Alert Icon */}
        <div className="mb-8">
          <div className="w-32 h-32 mx-auto bg-destructive text-white rounded-full flex items-center justify-center animate-pulse shadow-2xl shadow-destructive/40">
            <AlertTriangle className="w-16 h-16" />
          </div>
        </div>

        {/* Main Alert Content */}
        <h1 className="text-4xl sm:text-5xl font-bold text-destructive mb-4">
          EMERGENCY ALERT TRIGGERED
        </h1>

        <p className="text-xl text-muted-foreground mb-8">
          Panic scream detected. Emergency services are being notified.
        </p>

        {/* Location Info */}
        {location && (
          <div className="card-glass p-6 mb-8 border-destructive/20">
            <div className="flex items-center justify-center gap-2 mb-3">
              <MapPin className="w-5 h-5 text-destructive" />
              <span className="font-semibold">Your Location</span>
            </div>
            <p className="text-lg font-mono text-foreground">
              {location.latitude.toFixed(6)}, {location.longitude.toFixed(6)}
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              Location is being shared with emergency contacts and police
            </p>
          </div>
        )}

        {/* Countdown */}
        <div className="mb-8">
          <div className="card-glass p-8 border-2 border-destructive/40 mb-6">
            <p className="text-muted-foreground mb-4">Cancel alert in</p>
            <div
              className={`text-7xl font-bold transition-all duration-100 ${
                countdown <= 2
                  ? "text-destructive animate-pulse"
                  : "text-primary"
              }`}
            >
              {countdown}
            </div>
            <p className="text-muted-foreground mt-4">
              {countdown === 1 && "Sending now..."}
              {countdown === 0 && "Alert sent to emergency services"}
            </p>
          </div>

          {/* Cancel Button */}
          {countdown > 0 && (
            <button
              onClick={handleCancel}
              className="w-full bg-white border-2 border-destructive text-destructive font-bold py-4 rounded-2xl hover:bg-destructive/5 transition-all duration-200 flex items-center justify-center gap-2"
            >
              <X className="w-6 h-6" />
              CANCEL ALERT
            </button>
          )}

          {countdown === 0 && (
            <button
              onClick={handleCancel}
              className="w-full bg-primary text-primary-foreground font-bold py-4 rounded-2xl hover:bg-primary/90 transition-all"
            >
              RETURN TO HOME
            </button>
          )}
        </div>

        {/* Status Messages */}
        <div className="card-glass p-6 border-destructive/10">
          <h3 className="font-bold mb-4">Alert Status</h3>
          <div className="space-y-3 text-sm text-left">
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 bg-success rounded-full animate-pulse"></div>
              <span>Location acquired and locked</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 bg-success rounded-full animate-pulse"></div>
              <span>Preparing alert notification</span>
            </div>
            <div className="flex items-center gap-3">
              <div
                className={`w-3 h-3 rounded-full ${
                  countdown === 0 ? "bg-success" : "bg-warning"
                } ${countdown !== 0 ? "animate-pulse" : ""}`}
              ></div>
              <span>
                {countdown === 0
                  ? "Emergency alert sent to police dashboard"
                  : "Ready to send alert..."}
              </span>
            </div>
            <div className="flex items-center gap-3">
              <div
                className={`w-3 h-3 rounded-full ${
                  countdown === 0 ? "bg-success" : "bg-muted"
                }`}
              ></div>
              <span>Notifying emergency contacts</span>
            </div>
          </div>
        </div>

        {/* Emergency Contacts Info */}
        <div className="mt-8 card-glass p-6 bg-secondary/5 border-secondary/20">
          <h3 className="font-bold mb-3 flex items-center justify-center gap-2">
            <Phone className="w-5 h-5 text-secondary" />
            Emergency Contacts Being Notified
          </h3>
          <p className="text-sm text-muted-foreground">
            Your emergency contacts will receive an alert with your current location.
          </p>
        </div>
      </div>
    </div>
  );
}
