import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Trash2, Plus, Phone, User, ArrowLeft } from "lucide-react";

interface Contact {
  id: string;
  name: string;
  phone: string;
}

export default function EmergencyContacts() {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [newContact, setNewContact] = useState({ name: "", phone: "" });
  const [editingId, setEditingId] = useState<string | null>(null);

  // Load contacts from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("emergencyContacts");
    if (saved) {
      setContacts(JSON.parse(saved));
    }
  }, []);

  // Save contacts to localStorage
  const saveContacts = (updatedContacts: Contact[]) => {
    localStorage.setItem("emergencyContacts", JSON.stringify(updatedContacts));
    setContacts(updatedContacts);
  };

  const addContact = () => {
    if (!newContact.name || !newContact.phone) return;

    const contact: Contact = {
      id: Date.now().toString(),
      name: newContact.name,
      phone: newContact.phone,
    };

    saveContacts([...contacts, contact]);
    setNewContact({ name: "", phone: "" });
  };

  const deleteContact = (id: string) => {
    saveContacts(contacts.filter((c) => c.id !== id));
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 via-background to-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-border">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center gap-4">
          <Link to="/" className="p-2 hover:bg-muted rounded-lg transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-2xl font-bold">Emergency Contacts</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Info Card */}
        <div className="card-glass p-6 mb-8 border-primary/20">
          <p className="text-muted-foreground">
            Add trusted contacts who will be notified immediately when an emergency alert is triggered. They will receive your real-time location.
          </p>
        </div>

        {/* Add Contact Form */}
        <div className="card-glass p-6 mb-8 border-2 border-primary/20">
          <h2 className="text-xl font-bold mb-6">Add New Contact</h2>

          <div className="space-y-4 mb-6">
            <div>
              <label className="block text-sm font-semibold mb-2">Name</label>
              <input
                type="text"
                value={newContact.name}
                onChange={(e) =>
                  setNewContact({ ...newContact, name: e.target.value })
                }
                placeholder="Contact name"
                className="w-full px-4 py-2 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2">
                Phone Number
              </label>
              <input
                type="tel"
                value={newContact.phone}
                onChange={(e) =>
                  setNewContact({ ...newContact, phone: e.target.value })
                }
                placeholder="+1 (555) 123-4567"
                className="w-full px-4 py-2 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>

          <button
            onClick={addContact}
            disabled={!newContact.name || !newContact.phone}
            className="w-full btn-primary flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add Contact
          </button>
        </div>

        {/* Contacts List */}
        <div>
          <h2 className="text-xl font-bold mb-4">
            Your Contacts ({contacts.length})
          </h2>

          {contacts.length === 0 ? (
            <div className="card-glass p-12 text-center border-dashed border-2 border-muted">
              <User className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
              <p className="text-muted-foreground">
                No emergency contacts added yet. Add your first contact to get started.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {contacts.map((contact) => (
                <div
                  key={contact.id}
                  className="card-glass p-4 flex items-center justify-between border-primary/10 hover:border-primary/40 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center text-white font-bold">
                      {contact.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <h3 className="font-semibold">{contact.name}</h3>
                      <p className="text-sm text-muted-foreground flex items-center gap-1">
                        <Phone className="w-4 h-4" />
                        {contact.phone}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => deleteContact(contact.id)}
                    className="p-2 hover:bg-destructive/10 text-destructive rounded-lg transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Important Notice */}
        <div className="mt-12 card-glass p-6 bg-warning/5 border-warning/20">
          <h3 className="font-bold mb-3">⚠️ Important</h3>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>
              • Ensure all contacts are aware they may receive emergency alerts
            </li>
            <li>• Keep phone numbers updated and verified</li>
            <li>• Choose contacts who are reliable and responsive</li>
            <li>
              • Consider adding family, close friends, or local authorities
            </li>
          </ul>
        </div>

        {/* Back Button */}
        <div className="mt-8">
          <Link
            to="/"
            className="btn-outline w-full text-center"
          >
            Back to Home
          </Link>
        </div>
      </main>
    </div>
  );
}
