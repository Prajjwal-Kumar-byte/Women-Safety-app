import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { AlertCircle, Phone, MapPin, Settings, Shield, Mic } from "lucide-react";

export default function Index() {
  const [safetyActive, setSafetyActive] = useState(false);
  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [audioLevel, setAudioLevel] = useState(0);
  const [isListening, setIsListening] = useState(false);

  useEffect(() => {
    if (safetyActive) {
      startAudioListening();
      requestLocation();
    } else {
      stopAudioListening();
    }

    return () => {
      stopAudioListening();
    };
  }, [safetyActive]);

  const startAudioListening = async () => {
    try {
      setIsListening(true);
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const analyser = audioContext.createAnalyser();
      const microphone = audioContext.createMediaStreamSource(stream);
      microphone.connect(analyser);

      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      const checkAudio = () => {
        if (!isListening) return;
        analyser.getByteFrequencyData(dataArray);
        const average = dataArray.reduce((a, b) => a + b) / dataArray.length;
        setAudioLevel(Math.min(100, Math.round(average)));
        requestAnimationFrame(checkAudio);
      };
      checkAudio();
    } catch (error) {
      console.error("Error accessing microphone:", error);
      setIsListening(false);
    }
  };

  const stopAudioListening = () => {
    setIsListening(false);
    setAudioLevel(0);
  };

  const requestLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
        },
        (error) => {
          console.error("Error getting location:", error);
        }
      );
    }
  };

  const handleSafetyToggle = () => {
    setSafetyActive(!safetyActive);
  };

  const triggerEmergency = () => {
    window.location.href = "/emergency-alert";
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 via-background to-background overflow-hidden">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-border">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              SafeGuard
            </h1>
          </div>
          <Link
            to="/setup"
            className="p-2 hover:bg-muted rounded-lg transition-colors"
          >
            <Settings className="w-6 h-6 text-foreground" />
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Safety Toggle Card */}
        <div className="mb-8">
          <div className="card-glass border-2 border-primary/20 p-8 sm:p-12 text-center">
            <div className="mb-8">
              <h2 className="text-3xl font-bold mb-2">Safety Protection</h2>
              <p className="text-muted-foreground">
                {safetyActive
                  ? "Your safety is being monitored. Emergency alerts are enabled."
                  : "Enable protection to monitor for distress signals."}
              </p>
            </div>

            {/* Large Toggle Button */}
            <button
              onClick={handleSafetyToggle}
              className={`w-48 h-48 mx-auto rounded-full flex items-center justify-center justify-self-center transition-all duration-300 mb-8 relative ${
                safetyActive
                  ? "bg-gradient-to-br from-primary to-primary/80 shadow-lg shadow-primary/30 animate-scale-pulse"
                  : "bg-muted border-2 border-muted-foreground/20 hover:bg-muted/80"
              }`}
            >
              <div className="text-center">
                <Shield
                  className={`w-20 h-20 mx-auto mb-3 ${
                    safetyActive
                      ? "text-white animate-pulse"
                      : "text-muted-foreground"
                  }`}
                />
                <p
                  className={`font-bold text-lg ${
                    safetyActive
                      ? "text-white"
                      : "text-muted-foreground"
                  }`}
                >
                  {safetyActive ? "ON" : "OFF"}
                </p>
              </div>
            </button>

            {/* Audio Level Indicator */}
            {safetyActive && (
              <div className="mb-8">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <Mic className="w-5 h-5 text-primary" />
                  <span className="text-sm font-semibold text-foreground">
                    Audio Level
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-primary to-secondary h-full transition-all duration-75"
                    style={{ width: `${audioLevel}%` }}
                  />
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  Listening for distress sounds...
                </p>
              </div>
            )}

            {/* Location Status */}
            {safetyActive && (
              <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                <div className="flex items-center gap-2 justify-center text-sm">
                  <MapPin className="w-4 h-4 text-primary" />
                  <span className="text-foreground">
                    {location
                      ? `Location tracked: ${location.latitude.toFixed(4)}, ${location.longitude.toFixed(4)}`
                      : "Requesting location..."}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <Link
            to="/contacts"
            className="card-glass p-6 text-center hover:shadow-md hover:border-primary/40 transition-all"
          >
            <Phone className="w-8 h-8 text-secondary mx-auto mb-3" />
            <h3 className="font-semibold mb-1">Emergency Contacts</h3>
            <p className="text-sm text-muted-foreground">Manage contacts</p>
          </Link>

          <Link
            to="/tracking"
            className="card-glass p-6 text-center hover:shadow-md hover:border-primary/40 transition-all"
          >
            <MapPin className="w-8 h-8 text-primary mx-auto mb-3" />
            <h3 className="font-semibold mb-1">Live Tracking</h3>
            <p className="text-sm text-muted-foreground">View your location</p>
          </Link>

          <Link
            to="/dashboard"
            className="card-glass p-6 text-center hover:shadow-md hover:border-primary/40 transition-all"
          >
            <AlertCircle className="w-8 h-8 text-destructive mx-auto mb-3" />
            <h3 className="font-semibold mb-1">Police Dashboard</h3>
            <p className="text-sm text-muted-foreground">View alerts</p>
          </Link>
        </div>

        {/* Emergency Button */}
        <button
          onClick={triggerEmergency}
          className="w-full btn-secondary py-4 text-lg font-bold rounded-2xl shadow-lg hover:shadow-xl transition-all animate-pulse"
        >
          <AlertCircle className="w-6 h-6 inline-block mr-2" />
          EMERGENCY ALERT
        </button>

        {/* Info Section */}
        <div className="mt-12 card-glass p-6 border-primary/10">
          <h3 className="font-bold mb-4 flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-primary" />
            How it works
          </h3>
          <ul className="space-y-3 text-sm text-muted-foreground">
            <li className="flex gap-3">
              <span className="text-primary font-bold">1.</span>
              <span>Turn on Safety Protection to activate audio monitoring</span>
            </li>
            <li className="flex gap-3">
              <span className="text-primary font-bold">2.</span>
              <span>App detects panic screams, distress sounds, or "help" cries</span>
            </li>
            <li className="flex gap-3">
              <span className="text-primary font-bold">3.</span>
              <span>Automatic alert triggered with your live GPS location</span>
            </li>
            <li className="flex gap-3">
              <span className="text-primary font-bold">4.</span>
              <span>5-second countdown to cancel false triggers</span>
            </li>
            <li className="flex gap-3">
              <span className="text-primary font-bold">5.</span>
              <span>Alerts sent to emergency contacts and police dashboard</span>
            </li>
          </ul>
        </div>

        {/* Safety Tips */}
        <div className="mt-8 card-glass p-6 border-secondary/10 bg-secondary/5">
          <h3 className="font-bold mb-4 flex items-center gap-2">
            <Shield className="w-5 h-5 text-secondary" />
            Safety Tips
          </h3>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>✓ Keep your phone charged and within reach</li>
            <li>✓ Ensure location services are enabled</li>
            <li>✓ Update your emergency contacts regularly</li>
            <li>✓ Test the app in safe environments</li>
            <li>✓ Share your emergency contacts with trusted people</li>
          </ul>
        </div>
      </main>
    </div>
  );
}
