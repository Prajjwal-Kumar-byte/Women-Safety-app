import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { MapPin, Navigation, AlertCircle, ArrowLeft, Clock } from "lucide-react";

interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number;
  timestamp: Date;
}

export default function LiveTracking() {
  const [location, setLocation] = useState<LocationData | null>(null);
  const [isTracking, setIsTracking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [locationHistory, setLocationHistory] = useState<LocationData[]>([]);

  useEffect(() => {
    startTracking();
    return () => {
      stopTracking();
    };
  }, []);

  const startTracking = () => {
    setIsTracking(true);
    if (navigator.geolocation) {
      // Get initial position
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const newLocation: LocationData = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: new Date(),
          };
          setLocation(newLocation);
          setLocationHistory([newLocation]);
          setError(null);
        },
        (error) => {
          setError(error.message);
          setIsTracking(false);
        }
      );

      // Watch position for continuous updates
      const watchId = navigator.geolocation.watchPosition(
        (position) => {
          const newLocation: LocationData = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: new Date(),
          };
          setLocation(newLocation);
          setLocationHistory((prev) => [newLocation, ...prev].slice(0, 10));
        },
        (error) => {
          setError(error.message);
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0,
        }
      );

      return () => {
        navigator.geolocation.clearWatch(watchId);
      };
    }
  };

  const stopTracking = () => {
    setIsTracking(false);
  };

  const copyToClipboard = () => {
    if (location) {
      const text = `${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}`;
      navigator.clipboard.writeText(text);
    }
  };

  const getMapUrl = () => {
    if (!location) return "";
    return `https://maps.google.com/?q=${location.latitude},${location.longitude}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 via-background to-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center gap-4">
          <Link to="/" className="p-2 hover:bg-muted rounded-lg transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-2xl font-bold">Live Location Tracking</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Map Embed */}
        <div className="card-glass border-2 border-primary/20 overflow-hidden mb-8 h-96">
          {location ? (
            <iframe
              title="Location Map"
              width="100%"
              height="100%"
              frameBorder="0"
              src={`https://www.openstreetmap.org/export/embed.html?bbox=${(location.longitude - 0.01).toFixed(6)},${(location.latitude - 0.01).toFixed(6)},${(location.longitude + 0.01).toFixed(6)},${(location.latitude + 0.01).toFixed(6)}&layer=mapnik&marker=${location.latitude.toFixed(6)},${location.longitude.toFixed(6)}`}
            />
          ) : (
            <div className="flex items-center justify-center h-full bg-muted">
              <div className="text-center">
                <div className="animate-spin mb-4">
                  <Navigation className="w-8 h-8 text-primary mx-auto" />
                </div>
                <p className="text-muted-foreground">
                  {error ? error : "Getting location..."}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Current Location Card */}
        {location ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* Location Details */}
            <div className="card-glass p-6 border-primary/20">
              <h2 className="font-bold text-lg mb-4 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-primary" />
                Current Location
              </h2>

              <div className="space-y-4">
                <div className="bg-primary/5 p-4 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">Coordinates</p>
                  <p className="font-mono text-lg font-bold text-foreground">
                    {location.latitude.toFixed(8)}, {location.longitude.toFixed(8)}
                  </p>
                  <button
                    onClick={copyToClipboard}
                    className="text-sm text-primary hover:underline mt-2"
                  >
                    Copy coordinates
                  </button>
                </div>

                <div>
                  <p className="text-xs text-muted-foreground mb-1">Accuracy</p>
                  <p className="font-semibold">±{location.accuracy.toFixed(0)}m</p>
                </div>

                <div>
                  <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    Last Updated
                  </p>
                  <p className="font-semibold">
                    {location.timestamp.toLocaleTimeString()}
                  </p>
                </div>

                <a
                  href={getMapUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary w-full text-center"
                >
                  Open in Google Maps
                </a>
              </div>
            </div>

            {/* Tracking Status */}
            <div className="card-glass p-6 border-primary/20">
              <h2 className="font-bold text-lg mb-4">Tracking Status</h2>

              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-success/10 border border-success/30 rounded-lg">
                  <div>
                    <p className="font-semibold text-success">Tracking Active</p>
                    <p className="text-sm text-muted-foreground">
                      Location updates in real-time
                    </p>
                  </div>
                  <div className="w-3 h-3 bg-success rounded-full animate-pulse"></div>
                </div>

                <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
                  <p className="text-sm text-muted-foreground mb-2">
                    Update History
                  </p>
                  <p className="font-semibold">{locationHistory.length} updates</p>
                </div>

                <button
                  onClick={startTracking}
                  className="btn-secondary w-full"
                >
                  Refresh Location
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="card-glass p-12 text-center border-2 border-dashed border-muted mb-8">
            <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <p className="text-muted-foreground">
              {error || "Unable to get your location. Please enable location services."}
            </p>
            <button
              onClick={startTracking}
              className="btn-primary mt-6"
            >
              Try Again
            </button>
          </div>
        )}

        {/* Location History */}
        {locationHistory.length > 0 && (
          <div className="card-glass p-6 border-primary/10">
            <h2 className="font-bold text-lg mb-4">Recent Locations</h2>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {locationHistory.map((loc, index) => (
                <div
                  key={index}
                  className="flex justify-between items-center p-3 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div>
                    <p className="text-sm font-mono text-foreground">
                      {loc.latitude.toFixed(6)}, {loc.longitude.toFixed(6)}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {loc.timestamp.toLocaleTimeString()}
                    </p>
                  </div>
                  <span className="text-xs bg-primary/20 text-primary px-2 py-1 rounded">
                    ±{loc.accuracy.toFixed(0)}m
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Back Button */}
        <div className="mt-8">
          <Link to="/" className="btn-outline w-full text-center">
            Back to Home
          </Link>
        </div>
      </main>
    </div>
  );
}
