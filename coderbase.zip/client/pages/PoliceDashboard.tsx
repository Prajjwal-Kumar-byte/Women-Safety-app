import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { MapPin, AlertTriangle, Clock, Phone, User, CheckCircle, ArrowLeft, RefreshCw } from "lucide-react";

interface Alert {
  id: string;
  type: "PANIC_SCREAM" | "HELP_CRY" | "DISTRESS_SOUND";
  timestamp: Date;
  location: {
    latitude: number;
    longitude: number;
  };
  severity: "HIGH" | "CRITICAL";
  status: "ACTIVE" | "RESPONDED" | "RESOLVED";
  contactName?: string;
  contactPhone?: string;
  notes?: string;
}

export default function PoliceDashboard() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null);
  const [filterStatus, setFilterStatus] = useState<"ALL" | "ACTIVE" | "RESPONDED" | "RESOLVED">("ACTIVE");
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // Load alerts from localStorage (mock data)
    const loadAlerts = () => {
      const saved = localStorage.getItem("policeAlerts");
      if (saved) {
        setAlerts(
          JSON.parse(saved, (key, value) => {
            if (key === "timestamp") return new Date(value);
            return value;
          })
        );
      } else {
        // Add some mock alerts for demo
        const mockAlerts: Alert[] = [
          {
            id: "1",
            type: "PANIC_SCREAM",
            timestamp: new Date(Date.now() - 3600000),
            location: { latitude: 40.7128, longitude: -74.006 },
            severity: "CRITICAL",
            status: "RESPONDED",
            contactName: "Sarah Johnson",
            contactPhone: "+1 (555) 123-4567",
            notes: "Officer dispatched, victim assisted",
          },
          {
            id: "2",
            type: "HELP_CRY",
            timestamp: new Date(Date.now() - 1800000),
            location: { latitude: 40.758, longitude: -73.9855 },
            severity: "HIGH",
            status: "ACTIVE",
            contactName: "Emma Wilson",
            contactPhone: "+1 (555) 234-5678",
          },
          {
            id: "3",
            type: "DISTRESS_SOUND",
            timestamp: new Date(Date.now() - 900000),
            location: { latitude: 40.7489, longitude: -73.968 },
            severity: "HIGH",
            status: "ACTIVE",
            contactName: "Jessica Martinez",
            contactPhone: "+1 (555) 345-6789",
          },
        ];
        setAlerts(mockAlerts);
        localStorage.setItem("policeAlerts", JSON.stringify(mockAlerts));
      }
    };

    loadAlerts();
  }, []);

  const refreshAlerts = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  };

  const updateAlertStatus = (alertId: string, newStatus: Alert["status"]) => {
    const updated = alerts.map((alert) =>
      alert.id === alertId ? { ...alert, status: newStatus } : alert
    );
    setAlerts(updated);
    localStorage.setItem("policeAlerts", JSON.stringify(updated));
    if (selectedAlert?.id === alertId) {
      setSelectedAlert({ ...selectedAlert, status: newStatus });
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "PANIC_SCREAM":
        return "text-destructive";
      case "HELP_CRY":
        return "text-warning";
      case "DISTRESS_SOUND":
        return "text-destructive";
      default:
        return "text-foreground";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "ACTIVE":
        return "bg-destructive/20 text-destructive border-destructive/40";
      case "RESPONDED":
        return "bg-warning/20 text-warning border-warning/40";
      case "RESOLVED":
        return "bg-success/20 text-success border-success/40";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const filteredAlerts = alerts.filter((alert) => {
    if (filterStatus === "ALL") return true;
    return alert.status === filterStatus;
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 via-background to-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="/" className="p-2 hover:bg-muted rounded-lg transition-colors">
              <ArrowLeft className="w-6 h-6" />
            </Link>
            <h1 className="text-2xl font-bold">Police Dashboard</h1>
            <span className="px-3 py-1 bg-destructive/10 text-destructive text-sm font-semibold rounded-full">
              ADMIN
            </span>
          </div>
          <button
            onClick={refreshAlerts}
            disabled={isLoading}
            className="p-2 hover:bg-muted rounded-lg transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-6 h-6 ${isLoading ? "animate-spin" : ""}`} />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="card-glass p-6 border-destructive/20">
            <p className="text-sm text-muted-foreground mb-2">Total Alerts</p>
            <p className="text-3xl font-bold">{alerts.length}</p>
          </div>
          <div className="card-glass p-6 border-destructive/20">
            <p className="text-sm text-muted-foreground mb-2">Active</p>
            <p className="text-3xl font-bold text-destructive">
              {alerts.filter((a) => a.status === "ACTIVE").length}
            </p>
          </div>
          <div className="card-glass p-6 border-warning/20">
            <p className="text-sm text-muted-foreground mb-2">Responded</p>
            <p className="text-3xl font-bold text-warning">
              {alerts.filter((a) => a.status === "RESPONDED").length}
            </p>
          </div>
          <div className="card-glass p-6 border-success/20">
            <p className="text-sm text-muted-foreground mb-2">Resolved</p>
            <p className="text-3xl font-bold text-success">
              {alerts.filter((a) => a.status === "RESOLVED").length}
            </p>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 mb-6 flex-wrap">
          {(["ALL", "ACTIVE", "RESPONDED", "RESOLVED"] as const).map((status) => (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
                filterStatus === status
                  ? "bg-primary text-primary-foreground"
                  : "card-glass hover:border-primary/40"
              }`}
            >
              {status}
            </button>
          ))}
        </div>

        {/* Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Alerts List */}
          <div className="lg:col-span-2">
            <div className="card-glass border-primary/20 overflow-hidden">
              <div className="p-6 border-b border-border">
                <h2 className="text-xl font-bold">Emergency Alerts</h2>
              </div>

              {filteredAlerts.length === 0 ? (
                <div className="p-12 text-center">
                  <CheckCircle className="w-12 h-12 text-success mx-auto mb-4 opacity-50" />
                  <p className="text-muted-foreground">
                    No {filterStatus === "ALL" ? "" : filterStatus.toLowerCase()} alerts
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-border">
                  {filteredAlerts.map((alert) => (
                    <button
                      key={alert.id}
                      onClick={() => setSelectedAlert(alert)}
                      className={`w-full p-6 text-left hover:bg-muted/30 transition-colors border-l-4 ${
                        selectedAlert?.id === alert.id
                          ? "bg-primary/5 border-l-primary"
                          : "border-l-muted"
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <AlertTriangle
                            className={`w-5 h-5 ${getTypeColor(alert.type)}`}
                          />
                          <div>
                            <h3 className="font-bold">{alert.type.replace(/_/g, " ")}</h3>
                            <p className="text-sm text-muted-foreground">
                              {alert.contactName}
                            </p>
                          </div>
                        </div>
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-semibold border ${getStatusColor(alert.status)}`}
                        >
                          {alert.status}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-2">
                        <Clock className="w-4 h-4" />
                        {alert.timestamp.toLocaleTimeString()}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Alert Details */}
          <div className="lg:col-span-1">
            {selectedAlert ? (
              <div className="card-glass p-6 border-primary/20">
                <h3 className="text-lg font-bold mb-4">Alert Details</h3>

                <div className="space-y-4">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Alert Type</p>
                    <p className="font-semibold">{selectedAlert.type.replace(/_/g, " ")}</p>
                  </div>

                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Severity</p>
                    <span className={`px-2 py-1 rounded text-sm font-semibold ${
                      selectedAlert.severity === "CRITICAL"
                        ? "bg-destructive/20 text-destructive"
                        : "bg-warning/20 text-warning"
                    }`}>
                      {selectedAlert.severity}
                    </span>
                  </div>

                  <div>
                    <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      Timestamp
                    </p>
                    <p className="font-mono text-sm">
                      {selectedAlert.timestamp.toLocaleString()}
                    </p>
                  </div>

                  <div>
                    <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      Location
                    </p>
                    <p className="font-mono text-sm">
                      {selectedAlert.location.latitude.toFixed(6)},<br />
                      {selectedAlert.location.longitude.toFixed(6)}
                    </p>
                    <a
                      href={`https://maps.google.com/?q=${selectedAlert.location.latitude},${selectedAlert.location.longitude}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:underline text-xs mt-1 block"
                    >
                      View on map →
                    </a>
                  </div>

                  {selectedAlert.contactName && (
                    <div>
                      <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                        <User className="w-3 h-3" />
                        Contact
                      </p>
                      <p className="font-semibold">{selectedAlert.contactName}</p>
                      <p className="text-sm text-muted-foreground flex items-center gap-1">
                        <Phone className="w-3 h-3" />
                        {selectedAlert.contactPhone}
                      </p>
                    </div>
                  )}

                  {selectedAlert.notes && (
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Notes</p>
                      <p className="text-sm bg-muted/30 p-2 rounded">
                        {selectedAlert.notes}
                      </p>
                    </div>
                  )}

                  <div className="pt-4 border-t border-border space-y-2">
                    {selectedAlert.status !== "RESPONDED" && (
                      <button
                        onClick={() => updateAlertStatus(selectedAlert.id, "RESPONDED")}
                        className="btn-secondary w-full text-sm"
                      >
                        Mark as Responded
                      </button>
                    )}
                    {selectedAlert.status !== "RESOLVED" && (
                      <button
                        onClick={() => updateAlertStatus(selectedAlert.id, "RESOLVED")}
                        className="btn-primary w-full text-sm"
                      >
                        Mark as Resolved
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="card-glass p-6 border-2 border-dashed border-muted text-center">
                <AlertTriangle className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <p className="text-muted-foreground">Select an alert to view details</p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
