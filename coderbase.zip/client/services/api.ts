/**
 * API Services
 * Mock API endpoints for emergency alerts, contacts, and police dashboard
 * In production, these would connect to Firebase or a real backend
 */

import { LocationData } from "./locationService";

export interface EmergencyAlertPayload {
  type: "PANIC_SCREAM_DETECTED" | "HELP_CRY_DETECTED" | "DISTRESS_SOUND_DETECTED";
  location: {
    latitude: number;
    longitude: number;
    accuracy?: number;
  };
  timestamp: string;
  sourceType: "AUDIO_DETECTION" | "SHAKE_DETECTION" | "MANUAL" | "KEYWORD";
}

export interface ContactPayload {
  name: string;
  phone: string;
  email?: string;
}

export interface DashboardAlert {
  id: string;
  type: string;
  timestamp: string;
  location: {
    latitude: number;
    longitude: number;
  };
  status: string;
  severity: string;
}

/**
 * Send emergency alert to backend
 */
export async function sendEmergencyAlert(
  payload: EmergencyAlertPayload
): Promise<{ success: boolean; alertId: string }> {
  try {
    // Mock API call - in production this would be a real endpoint
    // await fetch("/api/emergency-alert", {
    //   method: "POST",
    //   headers: { "Content-Type": "application/json" },
    //   body: JSON.stringify(payload),
    // });

    const alertId = `alert-${Date.now()}`;
    console.log("Emergency alert sent:", { alertId, ...payload });

    // Store in localStorage for demo
    const alerts = JSON.parse(localStorage.getItem("alerts") || "[]");
    alerts.push({ id: alertId, ...payload, timestamp: new Date().toISOString() });
    localStorage.setItem("alerts", JSON.stringify(alerts));

    return {
      success: true,
      alertId,
    };
  } catch (error) {
    console.error("Error sending emergency alert:", error);
    return {
      success: false,
      alertId: "",
    };
  }
}

/**
 * Send alert to emergency contacts
 */
export async function notifyEmergencyContacts(
  alertId: string,
  contacts: ContactPayload[],
  location: LocationData
): Promise<boolean> {
  try {
    // Mock SMS/push notification service
    console.log("Notifying emergency contacts:", {
      alertId,
      contacts,
      location,
    });

    // In production, integrate with SMS service (Twilio, Firebase, etc.)
    for (const contact of contacts) {
      // Send SMS/notification
      // await sendSMS(contact.phone, `Emergency alert: ${location.latitude}, ${location.longitude}`);
      console.log(`Notifying ${contact.name} at ${contact.phone}`);
    }

    return true;
  } catch (error) {
    console.error("Error notifying contacts:", error);
    return false;
  }
}

/**
 * Get alerts for police dashboard
 */
export async function getPoliceAlerts(
  status?: "ACTIVE" | "RESPONDED" | "RESOLVED"
): Promise<DashboardAlert[]> {
  try {
    // In production, fetch from backend/Firebase
    const alerts = JSON.parse(localStorage.getItem("policeAlerts") || "[]");

    if (status) {
      return alerts.filter((a: any) => a.status === status);
    }

    return alerts;
  } catch (error) {
    console.error("Error fetching police alerts:", error);
    return [];
  }
}

/**
 * Update alert status (police dashboard)
 */
export async function updateAlertStatus(
  alertId: string,
  status: "ACTIVE" | "RESPONDED" | "RESOLVED"
): Promise<boolean> {
  try {
    const alerts = JSON.parse(localStorage.getItem("policeAlerts") || "[]");
    const alert = alerts.find((a: any) => a.id === alertId);

    if (alert) {
      alert.status = status;
      localStorage.setItem("policeAlerts", JSON.stringify(alerts));
      return true;
    }

    return false;
  } catch (error) {
    console.error("Error updating alert status:", error);
    return false;
  }
}

/**
 * Get user's emergency contacts
 */
export function getEmergencyContacts(): ContactPayload[] {
  try {
    const contacts = localStorage.getItem("emergencyContacts");
    return contacts ? JSON.parse(contacts) : [];
  } catch (error) {
    console.error("Error fetching contacts:", error);
    return [];
  }
}

/**
 * Save emergency contacts
 */
export function saveEmergencyContacts(contacts: ContactPayload[]): boolean {
  try {
    localStorage.setItem("emergencyContacts", JSON.stringify(contacts));
    return true;
  } catch (error) {
    console.error("Error saving contacts:", error);
    return false;
  }
}

/**
 * Get current user session (mock auth)
 */
export async function getCurrentUser(): Promise<{
  id: string;
  name: string;
  email: string;
} | null> {
  try {
    // In production, use Firebase Auth or similar
    const user = localStorage.getItem("currentUser");
    return user ? JSON.parse(user) : null;
  } catch (error) {
    console.error("Error getting current user:", error);
    return null;
  }
}

/**
 * Mock login function
 */
export async function login(email: string, password: string): Promise<boolean> {
  try {
    // In production, use Firebase Auth
    const user = {
      id: `user-${Date.now()}`,
      name: email.split("@")[0],
      email,
    };
    localStorage.setItem("currentUser", JSON.stringify(user));
    return true;
  } catch (error) {
    console.error("Error logging in:", error);
    return false;
  }
}

/**
 * Mock logout function
 */
export async function logout(): Promise<boolean> {
  try {
    localStorage.removeItem("currentUser");
    return true;
  } catch (error) {
    console.error("Error logging out:", error);
    return false;
  }
}

/**
 * Health check for backend
 */
export async function healthCheck(): Promise<boolean> {
  try {
    // In production, ping your backend
    console.log("Backend health check: OK");
    return true;
  } catch (error) {
    console.error("Backend health check failed:", error);
    return false;
  }
}
