/**
 * Audio Detection Service
 * Monitors ambient audio and detects panic screams, distress sounds, and help cries
 * Uses Web Audio API for real-time audio analysis
 */

export interface AudioDetectionConfig {
  sampleRate: number;
  fftSize: number;
  threshold: number;
  minFrequency: number;
  maxFrequency: number;
}

export interface DetectionResult {
  type: "PANIC_SCREAM" | "HELP_CRY" | "DISTRESS_SOUND" | "NORMAL";
  confidence: number;
  frequency: number;
  intensity: number;
  timestamp: Date;
}

export class AudioDetectionService {
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private microphone: MediaStreamAudioSourceNode | null = null;
  private stream: MediaStream | null = null;
  private isListening = false;
  private config: AudioDetectionConfig;
  private detectionCallback: ((result: DetectionResult) => void) | null = null;
  private animationFrameId: number | null = null;

  constructor(config?: Partial<AudioDetectionConfig>) {
    this.config = {
      sampleRate: 44100,
      fftSize: 2048,
      threshold: 60, // dB threshold for detection
      minFrequency: 300, // Hz - minimum frequency for scream detection
      maxFrequency: 4000, // Hz - maximum frequency for scream detection
      ...config,
    };
  }

  /**
   * Start listening to microphone audio
   */
  async startListening(onDetection: (result: DetectionResult) => void): Promise<void> {
    if (this.isListening) return;

    try {
      this.detectionCallback = onDetection;
      
      // Request microphone access
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: false,
        },
      });

      // Initialize audio context
      const audioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.audioContext = new audioContextClass();
      this.analyser = this.audioContext.createAnalyser();
      this.analyser.fftSize = this.config.fftSize;
      this.analyser.smoothingTimeConstant = 0.8;

      this.microphone = this.audioContext.createMediaStreamSource(this.stream);
      this.microphone.connect(this.analyser);

      this.isListening = true;
      this.analyzeAudio();
    } catch (error) {
      console.error("Error starting audio detection:", error);
      throw error;
    }
  }

  /**
   * Stop listening to microphone audio
   */
  stopListening(): void {
    this.isListening = false;

    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }

    if (this.stream) {
      this.stream.getTracks().forEach((track) => track.stop());
      this.stream = null;
    }

    if (this.microphone) {
      this.microphone.disconnect();
      this.microphone = null;
    }

    if (this.analyser) {
      this.analyser.disconnect();
      this.analyser = null;
    }

    if (this.audioContext && this.audioContext.state !== "closed") {
      this.audioContext.close();
      this.audioContext = null;
    }
  }

  /**
   * Main audio analysis loop
   */
  private analyzeAudio = (): void => {
    if (!this.isListening || !this.analyser) return;

    // Get frequency data
    const dataArray = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteFrequencyData(dataArray);

    // Analyze frequencies
    const result = this.analyzeFrequencies(dataArray);

    if (this.detectionCallback) {
      this.detectionCallback(result);
    }

    this.animationFrameId = requestAnimationFrame(this.analyzeAudio);
  };

  /**
   * Analyze frequency data to detect panic sounds
   */
  private analyzeFrequencies(dataArray: Uint8Array): DetectionResult {
    if (!this.analyser) {
      return {
        type: "NORMAL",
        confidence: 0,
        frequency: 0,
        intensity: 0,
        timestamp: new Date(),
      };
    }

    const nyquist = this.config.sampleRate / 2;
    const minBin = Math.floor(
      (this.config.minFrequency / nyquist) * dataArray.length
    );
    const maxBin = Math.floor(
      (this.config.maxFrequency / nyquist) * dataArray.length
    );

    // Calculate intensity in target frequency range
    let totalIntensity = 0;
    let peakFrequency = 0;
    let peakIntensity = 0;

    for (let i = minBin; i < maxBin; i++) {
      const intensity = dataArray[i];
      totalIntensity += intensity;

      if (intensity > peakIntensity) {
        peakIntensity = intensity;
        peakFrequency =
          ((i / dataArray.length) * nyquist * 1000) / 1000;
      }
    }

    // Calculate average intensity
    const averageIntensity = totalIntensity / (maxBin - minBin);
    const overallAverage = dataArray.reduce((a, b) => a + b) / dataArray.length;

    // Detection logic
    let detectionType: DetectionResult["type"] = "NORMAL";
    let confidence = 0;

    // Panic scream detection: high intensity + peak frequency in scream range
    if (averageIntensity > this.config.threshold && peakIntensity > 100) {
      detectionType = "PANIC_SCREAM";
      confidence = Math.min(100, (averageIntensity / 255) * 100 + 20);
    }
    // Distress sound detection: moderate-high intensity with fast changes
    else if (overallAverage > this.config.threshold - 10) {
      detectionType = "DISTRESS_SOUND";
      confidence = Math.min(100, (overallAverage / 255) * 80);
    }

    return {
      type: detectionType,
      confidence: Math.round(confidence),
      frequency: peakFrequency,
      intensity: Math.round(averageIntensity),
      timestamp: new Date(),
    };
  }

  /**
   * Get current audio level (0-100)
   */
  getAudioLevel(): number {
    if (!this.analyser) return 0;

    const dataArray = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteFrequencyData(dataArray);

    const average = dataArray.reduce((a, b) => a + b) / dataArray.length;
    return Math.min(100, Math.round((average / 255) * 100));
  }

  /**
   * Check if currently listening
   */
  isActive(): boolean {
    return this.isListening;
  }
}

// Export singleton instance
export const audioDetectionService = new AudioDetectionService();
