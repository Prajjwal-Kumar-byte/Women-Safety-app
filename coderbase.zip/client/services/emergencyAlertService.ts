/**
 * Emergency Alert Service
 * Handles creation and dispatch of emergency alerts
 */

import { LocationData } from "./locationService";

export interface EmergencyAlert {
  id: string;
  type: "PANIC_SCREAM_DETECTED" | "HELP_CRY_DETECTED" | "DISTRESS_SOUND_DETECTED" | "MANUAL_ALERT";
  timestamp: Date;
  location: {
    latitude: number;
    longitude: number;
    accuracy?: number;
  };
  status: "PENDING" | "SENT" | "ACKNOWLEDGED" | "RESPONDED" | "RESOLVED" | "CANCELLED";
  severity: "HIGH" | "CRITICAL";
  source: "AUDIO_DETECTION" | "SHAKE_DETECTION" | "MANUAL" | "KEYWORD";
  contactsNotified: string[];
  policeNotified: boolean;
  notes?: string;
}

export class EmergencyAlertService {
  private alerts: Map<string, EmergencyAlert> = new Map();
  private alertCallback: ((alert: EmergencyAlert) => void) | null = null;

  /**
   * Create a new emergency alert
   */
  createAlert(
    type: EmergencyAlert["type"],
    location: LocationData | { latitude: number; longitude: number },
    source: EmergencyAlert["source"],
    severity: EmergencyAlert["severity"] = "CRITICAL"
  ): EmergencyAlert {
    const alert: EmergencyAlert = {
      id: `alert-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type,
      timestamp: new Date(),
      location: {
        latitude: location.latitude,
        longitude: location.longitude,
        accuracy: "accuracy" in location ? location.accuracy : undefined,
      },
      status: "PENDING",
      severity,
      source,
      contactsNotified: [],
      policeNotified: false,
    };

    this.alerts.set(alert.id, alert);
    this.notifyAlertCreated(alert);

    return alert;
  }

  /**
   * Send alert to emergency contacts
   */
  async sendToContacts(
    alertId: string,
    contacts: Array<{ name: string; phone: string; email?: string }>
  ): Promise<boolean> {
    const alert = this.alerts.get(alertId);
    if (!alert) return false;

    try {
      // In production, this would send SMS/push notifications
      // For now, we'll just update the alert status
      const contactNames = contacts.map((c) => c.name);
      alert.contactsNotified = contactNames;
      alert.status = "SENT";

      // Mock API call
      console.log("Sending alert to emergency contacts:", {
        alertId,
        contacts,
        location: alert.location,
      });

      // Store contacts notification event
      this.storeAlertEvent(alertId, "CONTACTS_NOTIFIED", contactNames);

      return true;
    } catch (error) {
      console.error("Error sending to contacts:", error);
      return false;
    }
  }

  /**
   * Send alert to police dashboard
   */
  async sendToPolice(alertId: string): Promise<boolean> {
    const alert = this.alerts.get(alertId);
    if (!alert) return false;

    try {
      // In production, this would send to police API
      // For now, we'll store in localStorage (mock)
      const policeAlerts = JSON.parse(
        localStorage.getItem("policeAlerts") || "[]"
      );

      policeAlerts.push({
        ...alert,
        timestamp: alert.timestamp.toISOString(),
      });

      localStorage.setItem("policeAlerts", JSON.stringify(policeAlerts));

      alert.policeNotified = true;
      alert.status = "SENT";

      console.log("Alert sent to police dashboard:", alert);
      this.storeAlertEvent(alertId, "POLICE_NOTIFIED");

      return true;
    } catch (error) {
      console.error("Error sending to police:", error);
      return false;
    }
  }

  /**
   * Cancel an active alert
   */
  cancelAlert(alertId: string, reason?: string): boolean {
    const alert = this.alerts.get(alertId);
    if (!alert) return false;

    alert.status = "CANCELLED";
    if (reason) alert.notes = reason;

    this.storeAlertEvent(alertId, "CANCELLED", reason);
    return true;
  }

  /**
   * Update alert status
   */
  updateAlertStatus(
    alertId: string,
    status: EmergencyAlert["status"]
  ): boolean {
    const alert = this.alerts.get(alertId);
    if (!alert) return false;

    alert.status = status;
    this.storeAlertEvent(alertId, status);
    return true;
  }

  /**
   * Get alert by ID
   */
  getAlert(alertId: string): EmergencyAlert | null {
    return this.alerts.get(alertId) || null;
  }

  /**
   * Get all active alerts
   */
  getActiveAlerts(): EmergencyAlert[] {
    return Array.from(this.alerts.values()).filter((a) =>
      ["PENDING", "SENT", "ACKNOWLEDGED"].includes(a.status)
    );
  }

  /**
   * Get alert history
   */
  getAlertHistory(limit: number = 100): EmergencyAlert[] {
    return Array.from(this.alerts.values()).slice(-limit);
  }

  /**
   * Store alert event in history (mock)
   */
  private storeAlertEvent(alertId: string, event: string, data?: any): void {
    const events = JSON.parse(localStorage.getItem("alertEvents") || "[]");
    events.push({
      alertId,
      event,
      timestamp: new Date().toISOString(),
      data,
    });
    localStorage.setItem("alertEvents", JSON.stringify(events.slice(-1000)));
  }

  /**
   * Register callback for new alerts
   */
  onAlertCreated(callback: (alert: EmergencyAlert) => void): void {
    this.alertCallback = callback;
  }

  /**
   * Trigger alert created notification
   */
  private notifyAlertCreated(alert: EmergencyAlert): void {
    if (this.alertCallback) {
      this.alertCallback(alert);
    }
  }

  /**
   * Clear all alerts (for testing)
   */
  clearAlerts(): void {
    this.alerts.clear();
  }
}

// Export singleton instance
export const emergencyAlertService = new EmergencyAlertService();
