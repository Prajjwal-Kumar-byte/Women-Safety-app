/**
 * Keyword Detection Service
 * Detects specific keywords like "Help me!" or "Help" using Web Speech API
 */

export interface KeywordDetectionConfig {
  keywords: string[];
  confidence: number; // Minimum confidence (0-1)
  language: string;
  continuous: boolean;
}

export class KeywordDetectionService {
  private recognition: any = null;
  private isListening = false;
  private config: KeywordDetectionConfig;
  private detectionCallback: ((keyword: string, confidence: number) => void) | null = null;

  constructor(config?: Partial<KeywordDetectionConfig>) {
    this.config = {
      keywords: ["help me", "help", "somebody help"],
      confidence: 0.7, // 70% confidence threshold
      language: "en-US",
      continuous: true,
      ...config,
    };

    this.initializeRecognition();
  }

  /**
   * Initialize speech recognition
   */
  private initializeRecognition(): void {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      console.warn("Web Speech API not supported in this browser");
      return;
    }

    this.recognition = new SpeechRecognition();
    this.recognition.continuous = this.config.continuous;
    this.recognition.language = this.config.language;
    this.recognition.interimResults = true;

    this.recognition.onresult = (event: any) => {
      let interimTranscript = "";
      let finalTranscript = "";

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        const confidence = event.results[i][0].confidence;

        if (event.results[i].isFinal) {
          finalTranscript += transcript;
        } else {
          interimTranscript += transcript;
        }

        // Check for keywords
        this.checkKeywords(transcript, confidence);
      }
    };

    this.recognition.onerror = (event: any) => {
      console.error("Speech recognition error:", event.error);
    };

    this.recognition.onend = () => {
      this.isListening = false;
    };
  }

  /**
   * Start listening for keywords
   */
  startListening(onDetection: (keyword: string, confidence: number) => void): boolean {
    if (!this.recognition) {
      console.warn("Speech recognition not available");
      return false;
    }

    if (this.isListening) return false;

    try {
      this.detectionCallback = onDetection;
      this.recognition.start();
      this.isListening = true;
      return true;
    } catch (error) {
      console.error("Error starting keyword detection:", error);
      return false;
    }
  }

  /**
   * Stop listening for keywords
   */
  stopListening(): void {
    if (!this.recognition) return;

    try {
      this.recognition.stop();
      this.isListening = false;
    } catch (error) {
      console.error("Error stopping keyword detection:", error);
    }
  }

  /**
   * Check if spoken text contains emergency keywords
   */
  private checkKeywords(
    transcript: string,
    confidence: number
  ): void {
    const lowerTranscript = transcript.toLowerCase().trim();

    for (const keyword of this.config.keywords) {
      if (
        lowerTranscript.includes(keyword) &&
        confidence >= this.config.confidence
      ) {
        if (this.detectionCallback) {
          this.detectionCallback(keyword, confidence);
        }
      }
    }
  }

  /**
   * Check if currently listening
   */
  isActive(): boolean {
    return this.isListening;
  }

  /**
   * Check if browser supports Web Speech API
   */
  static isSupported(): boolean {
    return (
      "SpeechRecognition" in window || "webkitSpeechRecognition" in window
    );
  }

  /**
   * Update keywords
   */
  setKeywords(keywords: string[]): void {
    this.config.keywords = keywords;
  }

  /**
   * Update confidence threshold
   */
  setConfidence(confidence: number): void {
    this.config.confidence = Math.max(0, Math.min(1, confidence));
  }

  /**
   * Update language
   */
  setLanguage(language: string): void {
    this.config.language = language;
    if (this.recognition) {
      this.recognition.language = language;
    }
  }
}

// Export singleton instance
export const keywordDetectionService = new KeywordDetectionService();
