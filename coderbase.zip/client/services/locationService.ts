/**
 * Location Service
 * Handles GPS location tracking and geolocation
 */

export interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number;
  altitude: number | null;
  altitudeAccuracy: number | null;
  heading: number | null;
  speed: number | null;
  timestamp: Date;
}

export interface LocationError {
  code: number;
  message: string;
}

export class LocationService {
  private watchId: number | null = null;
  private isWatching = false;
  private lastLocation: LocationData | null = null;
  private locationCallback: ((location: LocationData) => void) | null = null;
  private errorCallback: ((error: LocationError) => void) | null = null;

  /**
   * Get current location once
   */
  getCurrentLocation(): Promise<LocationData> {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject({
          code: -1,
          message: "Geolocation not supported by this browser",
        });
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          const location = this.parsePosition(position);
          this.lastLocation = location;
          resolve(location);
        },
        (error) => {
          reject({
            code: error.code,
            message: this.getErrorMessage(error.code),
          });
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0,
        }
      );
    });
  }

  /**
   * Start watching location changes
   */
  startWatching(
    onLocation: (location: LocationData) => void,
    onError?: (error: LocationError) => void
  ): boolean {
    if (this.isWatching) return false;

    if (!navigator.geolocation) {
      const error: LocationError = {
        code: -1,
        message: "Geolocation not supported by this browser",
      };
      if (onError) onError(error);
      return false;
    }

    this.locationCallback = onLocation;
    if (onError) this.errorCallback = onError;

    this.watchId = navigator.geolocation.watchPosition(
      (position) => {
        const location = this.parsePosition(position);
        this.lastLocation = location;
        this.locationCallback?.(location);
      },
      (error) => {
        const errorObj: LocationError = {
          code: error.code,
          message: this.getErrorMessage(error.code),
        };
        this.errorCallback?.(errorObj);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      }
    );

    this.isWatching = true;
    return true;
  }

  /**
   * Stop watching location changes
   */
  stopWatching(): void {
    if (this.watchId !== null) {
      navigator.geolocation.clearWatch(this.watchId);
      this.watchId = null;
    }
    this.isWatching = false;
  }

  /**
   * Parse GeolocationPosition into LocationData
   */
  private parsePosition(position: GeolocationPosition): LocationData {
    return {
      latitude: position.coords.latitude,
      longitude: position.coords.longitude,
      accuracy: position.coords.accuracy,
      altitude: position.coords.altitude,
      altitudeAccuracy: position.coords.altitudeAccuracy,
      heading: position.coords.heading,
      speed: position.coords.speed,
      timestamp: new Date(position.timestamp),
    };
  }

  /**
   * Get human-readable error message
   */
  private getErrorMessage(code: number): string {
    switch (code) {
      case 1:
        return "Permission denied. Please enable location access.";
      case 2:
        return "Position unavailable. Unable to retrieve your location.";
      case 3:
        return "Location request timeout. Please try again.";
      default:
        return "An unknown error occurred while retrieving location.";
    }
  }

  /**
   * Get last known location
   */
  getLastLocation(): LocationData | null {
    return this.lastLocation;
  }

  /**
   * Check if currently watching
   */
  isWatchingLocation(): boolean {
    return this.isWatching;
  }

  /**
   * Calculate distance between two coordinates (Haversine formula)
   */
  static calculateDistance(
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number
  ): number {
    const R = 6371; // Earth's radius in km
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  /**
   * Format location for display
   */
  static formatLocation(location: LocationData): string {
    return `${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}`;
  }

  /**
   * Get Google Maps URL for location
   */
  static getMapsUrl(latitude: number, longitude: number): string {
    return `https://maps.google.com/?q=${latitude},${longitude}`;
  }
}

// Export singleton instance
export const locationService = new LocationService();
