/**
 * Shake Detection Service
 * Detects phone shake movements as an alternative trigger for emergency alerts
 */

export interface ShakeConfig {
  threshold: number; // Acceleration threshold (m/s²)
  duration: number; // Duration window in ms
  minShakes: number; // Minimum shakes to trigger
}

export class ShakeDetectionService {
  private isListening = false;
  private lastX = 0;
  private lastY = 0;
  private lastZ = 0;
  private lastTime = 0;
  private shakeCount = 0;
  private shakeCallback: (() => void) | null = null;
  private config: ShakeConfig;
  private shakeResetTimeout: NodeJS.Timeout | null = null;

  constructor(config?: Partial<ShakeConfig>) {
    this.config = {
      threshold: 15, // m/s² - acceleration threshold for shake
      duration: 1000, // 1 second window
      minShakes: 3, // Need 3 shakes to trigger
      ...config,
    };
  }

  /**
   * Start listening for device shake
   */
  startListening(onShake: () => void): boolean {
    if (this.isListening) return false;

    if (!("DeviceMotionEvent" in window)) {
      console.warn("DeviceMotionEvent not supported");
      return false;
    }

    this.shakeCallback = onShake;
    this.shakeCount = 0;

    // Request permission for iOS 13+
    if (typeof (DeviceMotionEvent as any).requestPermission === "function") {
      (DeviceMotionEvent as any)
        .requestPermission()
        .then((permission: string) => {
          if (permission === "granted") {
            window.addEventListener(
              "devicemotion",
              this.handleDeviceMotion,
              false
            );
            this.isListening = true;
          }
        })
        .catch((error: Error) => {
          console.error("Error requesting device motion permission:", error);
        });
    } else {
      // For non-iOS 13+ devices
      window.addEventListener("devicemotion", this.handleDeviceMotion, false);
      this.isListening = true;
    }

    return this.isListening;
  }

  /**
   * Stop listening for device shake
   */
  stopListening(): void {
    this.isListening = false;
    window.removeEventListener("devicemotion", this.handleDeviceMotion, false);

    if (this.shakeResetTimeout) {
      clearTimeout(this.shakeResetTimeout);
      this.shakeResetTimeout = null;
    }
  }

  /**
   * Handle device motion events
   */
  private handleDeviceMotion = (event: DeviceMotionEvent) => {
    if (!event.accelerationIncludingGravity) return;

    const acceleration = event.accelerationIncludingGravity;
    const now = event.timeStamp;

    // Calculate acceleration magnitude
    const x = acceleration.x || 0;
    const y = acceleration.y || 0;
    const z = acceleration.z || 0;

    const deltaX = Math.abs(x - this.lastX);
    const deltaY = Math.abs(y - this.lastY);
    const deltaZ = Math.abs(z - this.lastZ);

    const totalDelta = deltaX + deltaY + deltaZ;

    if (totalDelta > this.config.threshold) {
      this.shakeCount++;

      // Reset shake count after duration
      if (this.shakeResetTimeout) {
        clearTimeout(this.shakeResetTimeout);
      }

      this.shakeResetTimeout = setTimeout(() => {
        this.shakeCount = 0;
      }, this.config.duration);

      // Trigger callback if enough shakes detected
      if (this.shakeCount >= this.config.minShakes) {
        if (this.shakeCallback) {
          this.shakeCallback();
        }
        this.shakeCount = 0; // Reset after triggering
      }
    }

    this.lastX = x;
    this.lastY = y;
    this.lastZ = z;
    this.lastTime = now;
  };

  /**
   * Check if currently listening
   */
  isActive(): boolean {
    return this.isListening;
  }

  /**
   * Reset shake counter
   */
  resetShakeCount(): void {
    this.shakeCount = 0;
  }

  /**
   * Get current shake count
   */
  getShakeCount(): number {
    return this.shakeCount;
  }

  /**
   * Check if device motion is supported
   */
  static isSupported(): boolean {
    return "DeviceMotionEvent" in window;
  }

  /**
   * Check if requires permission (iOS 13+)
   */
  static requiresPermission(): boolean {
    return typeof (DeviceMotionEvent as any).requestPermission === "function";
  }
}

// Export singleton instance
export const shakeDetectionService = new ShakeDetectionService();
