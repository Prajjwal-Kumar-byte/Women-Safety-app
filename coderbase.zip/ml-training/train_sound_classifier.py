#!/usr/bin/env python3
"""
Women Safety App - Panic Sound Classifier Training Script

This script trains a sound classification model using TensorFlow/Keras to detect:
- Panic screams
- Help cries
- Distress sounds
- Normal background noise

Requirements:
    pip install tensorflow numpy librosa scikit-learn matplotlib

Training Data Structure:
    data/
    ├── panic_scream/     # Audio files of panic screams
    ├── help_cry/         # Audio files of "help" cries
    ├── distress_sound/   # Audio files of distress sounds
    └── normal/           # Audio files of background noise
"""

import os
import numpy as np
import librosa
import librosa.display
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import json
from pathlib import Path


class SoundClassifierTrainer:
    """Train a sound classifier for panic detection"""

    def __init__(
        self,
        sample_rate=22050,
        duration=2,
        n_mels=128,
        n_fft=2048,
        hop_length=512,
    ):
        """
        Initialize the trainer

        Args:
            sample_rate: Audio sample rate
            duration: Audio duration in seconds
            n_mels: Number of mel frequency bins
            n_fft: FFT window size
            hop_length: Samples between frames
        """
        self.sample_rate = sample_rate
        self.duration = duration
        self.n_samples = sample_rate * duration
        self.n_mels = n_mels
        self.n_fft = n_fft
        self.hop_length = hop_length

        self.scaler = StandardScaler()
        self.label_encoder = {
            "panic_scream": 0,
            "help_cry": 1,
            "distress_sound": 2,
            "normal": 3,
        }
        self.label_decoder = {v: k for k, v in self.label_encoder.items()}

    def load_audio(self, file_path):
        """Load and preprocess audio file"""
        try:
            audio, sr = librosa.load(file_path, sr=self.sample_rate, duration=self.duration)

            # Pad or truncate to exact duration
            if len(audio) < self.n_samples:
                audio = np.pad(audio, (0, self.n_samples - len(audio)))
            else:
                audio = audio[: self.n_samples]

            return audio
        except Exception as e:
            print(f"Error loading {file_path}: {e}")
            return None

    def extract_mel_spectrogram(self, audio):
        """Extract Mel Spectrogram features"""
        # Compute Mel Spectrogram
        mel_spec = librosa.feature.melspectrogram(
            y=audio,
            sr=self.sample_rate,
            n_mels=self.n_mels,
            n_fft=self.n_fft,
            hop_length=self.hop_length,
        )

        # Convert to dB scale
        mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)

        return mel_spec_db

    def extract_mfcc(self, audio):
        """Extract MFCC features"""
        mfcc = librosa.feature.mfcc(
            y=audio, sr=self.sample_rate, n_mfcc=13, n_fft=self.n_fft, hop_length=self.hop_length
        )
        return mfcc

    def extract_features(self, audio):
        """Extract multiple features from audio"""
        # Mel Spectrogram
        mel_spec = self.extract_mel_spectrogram(audio)

        # MFCC
        mfcc = self.extract_mfcc(audio)

        # Combine features
        features = np.vstack([mel_spec, mfcc])

        return features

    def load_dataset(self, data_dir="./data"):
        """Load all audio files from directory structure"""
        X = []
        y = []

        for label, label_id in self.label_encoder.items():
            label_dir = os.path.join(data_dir, label)

            if not os.path.exists(label_dir):
                print(f"Warning: Directory not found: {label_dir}")
                print(
                    f"Create sample data in: {os.path.abspath(label_dir)}"
                )
                continue

            audio_files = [
                f
                for f in os.listdir(label_dir)
                if f.endswith((".wav", ".mp3", ".ogg", ".flac"))
            ]

            print(f"Loading {len(audio_files)} {label} samples...")

            for audio_file in audio_files:
                file_path = os.path.join(label_dir, audio_file)
                audio = self.load_audio(file_path)

                if audio is not None:
                    features = self.extract_features(audio)
                    X.append(features)
                    y.append(label_id)

        if len(X) == 0:
            print("No audio files found. Using synthetic data for demo...")
            return self._generate_synthetic_data()

        return np.array(X), np.array(y)

    def _generate_synthetic_data(self, n_samples_per_class=5):
        """Generate synthetic data for demo purposes"""
        print("Generating synthetic training data...")
        X = []
        y = []

        for label_id in range(len(self.label_encoder)):
            for _ in range(n_samples_per_class):
                # Create random mel spectrogram features
                synthetic_features = np.random.randn(
                    self.n_mels + 13, 100
                ) * (label_id + 1)
                X.append(synthetic_features)
                y.append(label_id)

        return np.array(X), np.array(y)

    def build_model(self, input_shape):
        """Build CNN model for sound classification"""
        model = keras.Sequential(
            [
                # Input layer
                layers.Input(shape=input_shape),
                layers.Reshape((*input_shape, 1)),

                # Conv Block 1
                layers.Conv2D(32, kernel_size=(3, 3), activation="relu", padding="same"),
                layers.BatchNormalization(),
                layers.MaxPooling2D(pool_size=(2, 2)),
                layers.Dropout(0.25),

                # Conv Block 2
                layers.Conv2D(64, kernel_size=(3, 3), activation="relu", padding="same"),
                layers.BatchNormalization(),
                layers.MaxPooling2D(pool_size=(2, 2)),
                layers.Dropout(0.25),

                # Conv Block 3
                layers.Conv2D(128, kernel_size=(3, 3), activation="relu", padding="same"),
                layers.BatchNormalization(),
                layers.MaxPooling2D(pool_size=(2, 2)),
                layers.Dropout(0.25),

                # Global pooling and dense layers
                layers.GlobalAveragePooling2D(),
                layers.Dense(128, activation="relu"),
                layers.Dropout(0.5),
                layers.Dense(64, activation="relu"),
                layers.Dropout(0.5),
                layers.Dense(len(self.label_encoder), activation="softmax"),
            ]
        )

        model.compile(
            optimizer=keras.optimizers.Adam(learning_rate=0.001),
            loss="sparse_categorical_crossentropy",
            metrics=["accuracy"],
        )

        return model

    def train(self, data_dir="./data", epochs=50, batch_size=32):
        """Train the model"""
        # Load data
        print("Loading dataset...")
        X, y = self.load_dataset(data_dir)

        print(f"Dataset shape: {X.shape}")
        print(f"Labels: {np.unique(y)}")

        # Reshape for CNN
        X = X.reshape(X.shape[0], X.shape[1], X.shape[2])

        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )

        print(f"Training set size: {X_train.shape[0]}")
        print(f"Test set size: {X_test.shape[0]}")

        # Normalize features
        X_train_shape = X_train.shape
        X_train = X_train.reshape(-1)
        X_test = X_test.reshape(-1)

        self.scaler.fit(X_train.reshape(-1, 1))
        X_train = self.scaler.transform(X_train.reshape(-1, 1)).reshape(X_train_shape)
        X_test = self.scaler.transform(X_test.reshape(-1, 1)).reshape(X_test.shape)

        # Build and train model
        model = self.build_model(X_train.shape[1:])
        print(model.summary())

        history = model.fit(
            X_train,
            y_train,
            batch_size=batch_size,
            epochs=epochs,
            validation_split=0.1,
            callbacks=[
                keras.callbacks.EarlyStopping(
                    monitor="val_loss", patience=10, restore_best_weights=True
                )
            ],
        )

        # Evaluate
        test_loss, test_accuracy = model.evaluate(X_test, y_test)
        print(f"\nTest Accuracy: {test_accuracy:.4f}")

        # Plot history
        self._plot_training_history(history)

        return model, history, X_test, y_test

    def _plot_training_history(self, history):
        """Plot training history"""
        fig, axes = plt.subplots(1, 2, figsize=(12, 4))

        axes[0].plot(history.history["loss"], label="Training Loss")
        axes[0].plot(history.history["val_loss"], label="Validation Loss")
        axes[0].set_title("Loss")
        axes[0].set_xlabel("Epoch")
        axes[0].set_ylabel("Loss")
        axes[0].legend()

        axes[1].plot(history.history["accuracy"], label="Training Accuracy")
        axes[1].plot(history.history["val_accuracy"], label="Validation Accuracy")
        axes[1].set_title("Accuracy")
        axes[1].set_xlabel("Epoch")
        axes[1].set_ylabel("Accuracy")
        axes[1].legend()

        plt.tight_layout()
        plt.savefig("./training_history.png")
        print("Saved training history to training_history.png")

    def save_model(self, model, model_path="./sound_classifier.h5"):
        """Save trained model"""
        model.save(model_path)
        print(f"Model saved to {model_path}")

        # Save metadata
        metadata = {
            "sample_rate": self.sample_rate,
            "duration": self.duration,
            "n_mels": self.n_mels,
            "n_fft": self.n_fft,
            "hop_length": self.hop_length,
            "label_decoder": self.label_decoder,
        }
        with open("./model_metadata.json", "w") as f:
            json.dump(metadata, f)
        print("Model metadata saved to model_metadata.json")

    def convert_to_tflite(self, model, output_path="./sound_classifier.tflite"):
        """Convert TensorFlow model to TFLite format"""
        converter = tf.lite.TFLiteConverter.from_keras_model(model)
        converter.target_spec.supported_ops = [
            tf.lite.OpsSet.TFLITE_BUILTINS,
            tf.lite.OpsSet.SELECT_TF_OPS,
        ]
        tflite_model = converter.convert()

        with open(output_path, "wb") as f:
            f.write(tflite_model)

        print(f"TFLite model saved to {output_path}")
        print(f"Model size: {os.path.getsize(output_path) / 1024:.2f} KB")


def main():
    """Main training pipeline"""
    print("=== Women Safety App - Panic Sound Classifier ===\n")

    # Initialize trainer
    trainer = SoundClassifierTrainer(
        sample_rate=22050,
        duration=2,
        n_mels=128,
    )

    # Create data directory structure
    data_dir = "./data"
    for label in ["panic_scream", "help_cry", "distress_sound", "normal"]:
        os.makedirs(os.path.join(data_dir, label), exist_ok=True)

    print("Instructions for training with your data:")
    print(f"1. Place audio files in {data_dir}/<class>/ directories")
    print("2. Supported formats: .wav, .mp3, .ogg, .flac\n")

    # Train model
    model, history, X_test, y_test = trainer.train(data_dir, epochs=50)

    # Save model
    trainer.save_model(model)

    # Convert to TFLite
    print("\nConverting to TensorFlow Lite...")
    trainer.convert_to_tflite(model)

    print("\n✅ Training complete!")
    print("Next steps:")
    print("1. Review training_history.png for model performance")
    print("2. Download sound_classifier.tflite for mobile deployment")
    print("3. Update the Web Audio API integration with the new model")


if __name__ == "__main__":
    main()
